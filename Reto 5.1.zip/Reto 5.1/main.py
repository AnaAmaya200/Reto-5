import math
import paquete.shape as shape


bottom_left_corner_rect = shape.Point(0, 0)
upper_right_corner_rect = shape.Point(4, 3)
    
bottom_left_corner_square = shape.Point(0, 0)
upper_right_corner_square = shape.Point(3, 3)
    

rect = shape.Rectangle(bottom_left_corner_rect, upper_right_corner_rect)
square = shape.Square(bottom_left_corner_square, upper_right_corner_square)

print(f"El rectángulo tiene área de {rect.compute_area():.2f} y perímetro de {rect.compute_perimeter():.2f}")
print(f"Sus ángulos internos son {rect.compute_inner_angles()}")
    
print ("\n")

print(f"El cuadrado tiene área de {square.compute_area():.2f} y perímetro de{square.compute_perimeter():.2f}")
print(f"Sus ángulos internos son {square.compute_inner_angles()}")

print ("\n")

p1 = shape.Point(0, 0)
p2 = shape.Point(4, 0)
p3 = shape.Point(2, 4)
p4 = shape.Point(3, 0)
p5 = shape.Point(3, 3)

triangle = shape.Triangle(p1, p2, p3)
isosceles = shape.Isosceles(p1, p2, p3)
equilateral = shape.Equilateral(p1, shape.Point(4, 0), shape.Point(2, math.sqrt(12)))
scalene = shape.Scalene(p1, p4, p5)
trirectangle = shape.Trirectangle(p1, p2, shape.Point(4, 3))

 

print(f"El triangulo inicial tiene un perímetro de {triangle.compute_perimeter():.2f}")

print ("\n")

print(f"El triangulo isosceles tiene un área de {isosceles.compute_area():.2f}, un perímetro de {isosceles.compute_perimeter():.2f}")

print(f"Sus ángulos internos son {isosceles.compute_inner_angles()}")
    
print ("\n")
print(f"El triangulo equilátero tiene un área de {equilateral.compute_area():.2f}, un perímetro de {equilateral.compute_perimeter():.2f}")
print(f"Sus ángulos internos son {equilateral.compute_inner_angles()}")

print ("\n")

print(f"El triangulo escaleno tiene un área de {scalene.compute_area():.2f}, un perímetro de  {scalene.compute_perimeter():.2f}")
print(f"Sus ángulos internos son {scalene.compute_inner_angles()}")

print ("\n")
print(f"El triangulo rectángulo tiene un área de {trirectangle.compute_area():.2f}, un perímetro de {trirectangle.compute_perimeter():.2f}")
