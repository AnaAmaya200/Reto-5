import math
from paquete.Line import Line
from paquete.Triangle import Triangle



class Scalene(Triangle):
  def __init__(self, Bottom_left_corner, Bottom_right_corner, Upper_corner):
    super().__init__(Bottom_left_corner, Bottom_right_corner, Upper_corner)
  
  def compute_perimeter(self):
    return super().compute_perimeter()
  
  def compute_area(self):
        s = self.compute_perimeter() / 2 
        c = Line.compute_length(self.edges[2])
        return math.sqrt(s * (s - Line.compute_length(self.edges[0])) * (s - (Line.compute_length(self.edges[1]))) * (s - (Line.compute_length(self.edges[2]))))
    
  def compute_inner_angles(self):

        
        A = math.degrees(math.acos(((Line.compute_length(self.edges[1]))**2 + (Line.compute_length(self.edges[2]))**2 - (Line.compute_length(self.edges[0]))**2) / (2 * (Line.compute_length(self.edges[1])) * (Line.compute_length(self.edges[2])))))
        B = math.degrees(math.acos(((Line.compute_length(self.edges[0]))**2 + (Line.compute_length(self.edges[2]))**2 - (Line.compute_length(self.edges[1]))**2) / (2 * (Line.compute_length(self.edges[0])) * (Line.compute_length(self.edges[2])))))
        C = 180 - A - B
        
        self.inner_angles.append(A)
        self.inner_angles.append(B)
        self.inner_angles.append(C)
        return self.inner_angles
