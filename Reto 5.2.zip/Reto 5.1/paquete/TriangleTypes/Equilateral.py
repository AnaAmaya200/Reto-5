import math
from paquete.Line import Line
from paquete.Triangle import Triangle


class Equilateral(Triangle):
  def __init__(self, Bottom_left_corner, Bottom_right_corner, Upper_corner):
    super().__init__(Bottom_left_corner, Bottom_right_corner, Upper_corner)
    self.is_regular = True

  def compute_area(self):
    return (((Line.compute_length(self.edges[0]))**2)*math.sqrt(3))/4
  
  def compute_perimeter(self):
    return super().compute_perimeter()
  
  def compute_inner_angles(self):
    self.compute_inner_angles = [60]*3
    return self.compute_inner_angles 
