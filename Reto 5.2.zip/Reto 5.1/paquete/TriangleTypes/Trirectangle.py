import math
import paquete.Line as Line
from paquete.Line import Line
from paquete.Triangle import Triangle


class Trirectangle(Triangle):
  def __init__(self, Bottom_left_corner, Bottom_right_corner, Upper_corner):
    super().__init__(Bottom_left_corner, Bottom_right_corner, Upper_corner)

  def compute_perimeter(self):
    return super().compute_perimeter()
  
  def compute_area(self):
    if self.vertices[1].y == self.vertices[2].y :
      return (Line.compute_length(self.edges[0])* Line.compute_length(self.edges[1]))/2
    else:
      return (Line.compute_length(self.edges[0])* Line.compute_length(self.edges[2]))/2
    
  def compute_inner_angles(self):
    a = 90
    if self.vertices[1].y == self.vertices[2].y :
      b = math.atan(Line.compute_length(self.edges[1])/ Line.compute_length(self.edges[0]))
    else:
      b = math.atan(Line.compute_length(self.edges[2])/ Line.compute_length(self.edges[0]))
    c = a - b
    self.inner_angles.append(a)
    self.inner_angles.append(b)
    self.inner_angles.append(c)