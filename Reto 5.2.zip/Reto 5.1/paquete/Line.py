from paquete.Point import Point
class Line:
  def __init__(self,start: Point,end: Point):
    self.start = start
    self.end = end
  def compute_length(self):
    self.length = (round(Point.compute_distance(self.start, self.end),2))
    return self.length