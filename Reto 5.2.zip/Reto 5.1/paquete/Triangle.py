from paquete.Shape import Shape
from paquete.Line import Line


class Triangle(Shape):
  def __init__(self, Bottom_left_corner, Bottom_right_corner, Upper_corner):
    super().__init__()
    self.is_regular = False
    self.vertices.append(Bottom_left_corner)
    self.vertices.append(Bottom_right_corner)
    self.vertices.append(Upper_corner)
    self.edges.append(Line(Bottom_left_corner,Bottom_right_corner))
    self.edges.append(Line(Bottom_right_corner,Upper_corner))
    self.edges.append(Line(Upper_corner,Bottom_left_corner))
  def compute_perimeter(self):
    return Line.compute_length(self.edges[0]) + Line.compute_length(self.edges[1]) + Line.compute_length(self.edges[2])
  