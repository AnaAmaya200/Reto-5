from paquete.Rectangle import Rectangle

class Square(Rectangle):
  def __init__(self, Bottom_left_corner, Upper_right_corner):
    super().__init__(Bottom_left_corner, Upper_right_corner)
    self.is_regular = True
  def compute_area(self):
    return super().compute_area()
  def compute_inner_angles(self):
    return super().compute_inner_angles()
