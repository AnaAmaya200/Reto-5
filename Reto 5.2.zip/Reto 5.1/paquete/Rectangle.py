from paquete.Shape import Shape
from paquete.Line import Line
from paquete.Point import Point

class Rectangle(Shape):
    def __init__(self, bottom_left_corner, upper_right_corner):
        super().__init__()
        self.is_regular = False
        bottom_right_corner = Point(upper_right_corner.x, bottom_left_corner.y)
        upper_left_corner = Point(bottom_left_corner.x, upper_right_corner.y)
        self.vertices.append(bottom_left_corner)
        self.vertices.append(upper_left_corner)
        self.vertices.append(upper_right_corner)
        self.vertices.append(bottom_right_corner)
        self.edges.append(Line(bottom_left_corner, upper_left_corner))
        self.edges.append(Line(upper_left_corner, upper_right_corner))
        self.edges.append(Line(upper_right_corner, bottom_right_corner))
        self.edges.append(Line(bottom_right_corner, bottom_left_corner))
    
    def compute_area(self):
        return self.edges[0].compute_length() * self.edges[1].compute_length()

    def compute_perimeter(self):
        return (2 * self.edges[0].compute_length()) + (2 * self.edges[1].compute_length())

    def compute_inner_angles(self):
        self.inner_angles = [90] * 4
        return self.inner_angles


